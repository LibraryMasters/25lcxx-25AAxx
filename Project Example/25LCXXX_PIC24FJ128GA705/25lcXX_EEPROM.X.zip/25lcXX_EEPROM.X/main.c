/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.171.1
        Device            :  PIC24FJ128GA705
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.70
        MPLAB 	          :  MPLAB X v5.50
 */

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
 */

/**
  Section: Included Files
 */
#include "mcc_generated_files/system.h"
#include "utilies_file.h"
#include "mcc_generated_files/pin_manager.h"
#include "25LCxx_driver_basic.h"


void led_toggling(void);
uint32_t led_time_check;

/*spi declare functions */
void spi_chip_select(bool state);
uint8_t spi_write(uint16_t u16Reg, uint32_t *pbuf, uint16_t u16Len);
uint8_t spi_read(uint16_t u16Reg, uint32_t *pbuf, uint16_t u16Len);

/*demo application definition */

typedef enum
{
	WRITE_BYTE        = 1,     
	READ_BYTE         = 2,
	EE_PUT            = 3,
	EE_GET            = 4,
	EE_UPDATE         = 5,
	PAGE_ERASE        = 6,
	SECTOR_ERASE      = 7,
	SET_BLOCK_PROTECT = 8,
	CHIP_ERASE        = 9,
	READ_FULL_MEMORY  = 10,
	DEMO_IDLE         = 0

}e25lcxx_demo_state_t;

typedef struct handle_s
{
	e25lcxx_demo_state_t state;
}e25lxx_state_handler_t;

e25lxx_state_handler_t demo;

/*
                         Main application
 */

E_25LCxx_info_t e_25LCxxInfo; /**< driver info handler definition */

uint16_t u16EE_addr;
uint8_t pBufferWrite[50];
uint8_t pBufferRead[10];
uint32_t u32DateAndTime;
uint16_t u16AddrIndex;
uint8_t u8PreviousState, u8PreviousState1;
uint16_t u16BufferLength;

int main(void) {
    // initialize the device
    SYSTEM_Initialize();
    
    e_25LCxx_interface_delay_ms(1000);
    e_25LCxx_basic_initialize(E_25LC160x_TYPE, E_25LCXX_PAGE_SIZE_16_BYTE);
    E_25LCxx_info(&e_25LCxxInfo);

#ifdef E_25LCXX_DEBUG_MODE
    e_25LCxx_interface_debug_print("Chip Name: \t%s\r\n", e_25LCxxInfo.chip_name);
    e_25LCxx_interface_debug_print("Manufacture: \t%s\r\n", e_25LCxxInfo.manufacturer_name);
    e_25LCxx_interface_debug_print("Interface: \t%s\r\n", e_25LCxxInfo.interface);
    e_25LCxx_interface_debug_print("Supply Volt Max: \t%.1fV\r\n", e_25LCxxInfo.supply_voltage_max_v);
    e_25LCxx_interface_debug_print("Supply Volt Min: \t%.1fV\r\n", e_25LCxxInfo.supply_voltage_min_v);
    e_25LCxx_interface_debug_print("Maximum Current: \t%.1fmA\r\n", e_25LCxxInfo.max_current_ma);
    e_25LCxx_interface_debug_print("Temperature Max: \t%.1fC\r\n", e_25LCxxInfo.temperature_max);
    e_25LCxx_interface_debug_print("Temperature Min: \t%.1fC\r\n", e_25LCxxInfo.temperature_min);
    e_25LCxx_interface_debug_print("Temperature Min: \tV%.2f\r\n", (e_25LCxxInfo.driver_version / 1000));
    e_25LCxx_interface_debug_print("\n");
#endif
    
		demo.state = DEMO_IDLE;

    while (1) {
        non_blocking_task(&led_toggling, _500_MS_TIMEOUT, led_time_check);
        switch(demo.state)
		{

			case DEMO_IDLE:
			{
				e_25LCxx_interface_debug_print("STATE:%d IDLE\r\n", DEMO_IDLE);
				if(u8PreviousState == READ_FULL_MEMORY)
				{
					e_25LCxx_interface_debug_print("\t\tEND OF DEMO CODE!! :-)\r\n");
					return 1;
				}
				e_25LCxx_interface_debug_print("\t\t\t* Demo code to demonstrate basic functionalities of EEPROM Driver.\r\n");
				e_25LCxx_interface_debug_print("\t\t\t* Note that it is strongly recommended to disable debug mode"
				"('E_25LCXX_DEBUG_MODE' find in 25LCxx_driver.h ) in order to reduce the code size.\r\n");
				e_25LCxx_interface_debug_print("\t\t\t* Note that enabling printing of float will increase code size.\r\n");
				e_25LCxx_interface_debug_print("\t\t\t* In order to enable printing of float on Microchip Studio go to:Project->properties->AVR/GNU Linker ->Miscellaneous ->other linker flags and type -> -lprintf_flt \r\n");
				demo.state = READ_BYTE;       /**< go to next state to begin testing */
				break;
			}

			case WRITE_BYTE:
			{
				e_25LCxx_interface_debug_print("STATE:%d WRITE BYTE\r\n", WRITE_BYTE);
				u16EE_addr = 0;                                                        /**< define start address (write from address 0) */
				u16BufferLength = 10;                                                  /**< set buffer length (number of byte to be written) */
				if(u8PreviousState == SET_BLOCK_PROTECT){                              /**< if block protect is set, define address to write equal to the EEPROM max addr - 10 */
					u16EE_addr = e_25LCxx_basic_get_eeprom_legth() - u16BufferLength;
				}
				memset(pBufferWrite, 52, u16BufferLength);                             /**< Give the 10 first byte of buffer a value of 34 */
				if(e_25LCxx_basic_write_byte(u16EE_addr, (uint8_t*)pBufferWrite, u16BufferLength)) /**< write n number of byte to EEPROM */
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", WRITE_BYTE);
					demo.state =  DEMO_IDLE;                                           /**< start over from idle */
				}if(u8PreviousState == SET_BLOCK_PROTECT)
				demo.state = CHIP_ERASE;
				else
				demo.state =  READ_BYTE;                                              /**< move to next state if read successful*/

				break;
			}

			case READ_BYTE:
			{
				e_25LCxx_interface_debug_print("STATE:%d READ BYTE \r\n", READ_BYTE);
				u16EE_addr = 5;												      /**< define start address to read from(read from address 5) */
				u16BufferLength = 10;                                                 /**< set buffer length to read */
				memset(pBufferRead, 0x00, u16BufferLength);                           /**< clear buffer before read */
				if(e_25LCxx_basic_read_byte(u16EE_addr, (uint8_t*)pBufferRead, u16BufferLength))  /**< read 10 byte starting from address defined above*/
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", READ_BYTE);
					demo.state =  DEMO_IDLE;                                          /**< start over from idle if failed */
					return 1;														  /**< return error code */
					}else{
					for(u16AddrIndex = 0; u16AddrIndex < u16BufferLength; u16AddrIndex++){        /**< print read data */
						e_25LCxx_interface_debug_print("address: %d, data = %d\r\n", u16AddrIndex + u16EE_addr, pBufferRead[u16AddrIndex]);
					}
					if(u8PreviousState == PAGE_ERASE)                                 /**< go to sector erase if previous state was PAGE ERASE */
					demo.state = SECTOR_ERASE;
					else
					demo.state =  EE_PUT;                                             /**< move to next state if write successful*/
				}

				break;
			}

			case EE_PUT:
			{
				e_25LCxx_interface_debug_print("STATE:%d EEPROM PUT\r\n", EE_PUT);
				u16EE_addr = 15;                                                    /**< set address to start writing from */
				u32DateAndTime = 2209041513;                                        /**< prepare data to be stored as date and time this demo code was written (04/09/2022 - 15:43) */
				if(e_25LCxx_basic_put_byte(u16EE_addr, (unsigned long long *)&u32DateAndTime, sizeof(u32DateAndTime))) /**< 4 byte is needed to write date and time (from addr : 15 - 18)*/
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", EE_PUT);
					demo.state =  DEMO_IDLE;                                        /**< start over from idle if failed */
					return 1;														 /**< return error code */
					}else{
					demo.state =  EE_GET;                                           /**< move to next state if read successful*/
				}
				break;
			}

			case EE_GET:
			{
				e_25LCxx_interface_debug_print("STATE:%d EEPROM GET\r\n", EE_GET);
				u16EE_addr = 15;                                                    /**< set address to start reading from */
				u32DateAndTime = 0x00;                                              /**< make sure date and time variable is cleared before reading */
				if(e_25LCxx_basic_get_byte(u16EE_addr, (unsigned long long *)&u32DateAndTime, sizeof(u32DateAndTime))) /**< read 4 byte starting for address defined above */
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", EE_GET);
					demo.state =  DEMO_IDLE;                                        /**< start over from idle if failed */
					return 1;														 /**< return error code */
					}else{
					e_25LCxx_interface_debug_print("Time and date stored:%lu\r\n", u32DateAndTime); /**< print read data */
					if(u8PreviousState == SECTOR_ERASE){
						demo.state =  SET_BLOCK_PROTECT;                            /**< go to block protect state if previous state was sector erase */
						}  else{
						demo.state = EE_UPDATE;
					}

				}
				break;
			}

			case EE_UPDATE:
			{
				e_25LCxx_interface_debug_print("STATE:%d EEPROM UPDATE\r\n", EE_UPDATE);
				u16EE_addr = 19;                                                    /**< set start address*/
				u16BufferLength = 3;                                                /**< define buffer length (number of bytes to be updated */
				memset(pBufferWrite, 52, u16BufferLength);                          /**< set first 3 byte of array to 89 */
				if(e_25LCxx_basic_update(u16EE_addr, (uint8_t *)pBufferWrite, u16BufferLength))   /**< run update routine */
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", EE_UPDATE);
					demo.state =  DEMO_IDLE;                                        /**< start over from idle if failed */
					return 1;														 /**< return error code */
					}else{
					demo.state = PAGE_ERASE;                                        /**< move to next state if write successful*/
				}
				break;
			}

			case PAGE_ERASE:
			{
				e_25LCxx_interface_debug_print("STATE:%d PAGE ERASE\r\n", PAGE_ERASE);
				if(e_25LCxx_basic_erase_page(1))                                    /**< erase first page of the memory */
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", PAGE_ERASE);
					demo.state =  DEMO_IDLE;                                        /**< start over from idle if failed */
					return 1;														 /**< return error code */
					}else{
					u8PreviousState = demo.state;                                   /**< keep track of previous state */
					demo.state = READ_BYTE;                                         /**< go back to read state to confirm page has been erased */
				}
				break;
			}

			//Note: Sector erase will erase data from start addr to end addr (255 is the default value when erasing).
			// Note: This function uses e_25LCxx_basic_update() to perform the write, so does not rewrites the value if it didn't change */
			//We will attempt to delete the stored date and time we stored in state:EE_PUT
			case SECTOR_ERASE:
			{
				e_25LCxx_interface_debug_print("STATE:%d SECTOR ERASE\r\n", SECTOR_ERASE);
				u16EE_addr = 15;                                                    /**< define sector start address */
				if(e_25LCxx_basic_erase_sector(u16EE_addr, (u16EE_addr + sizeof(u32DateAndTime))- 1)) /**< execute erase sector instruction from address 15 - 18*/
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", SECTOR_ERASE);
					demo.state =  DEMO_IDLE;                                        /**< start over from idle if failed */
					return 1;														 /**< return error code */
				}
				u8PreviousState = SECTOR_ERASE;                                     /**< keep track of previous state */
				//				 e_25LCxx_interface_debug_print("previous state %d, current state:%d\r\n",u8PreviousState,demo.state);
				demo.state =  EE_GET;                                               /**< go read if the date and time has been erased successfully */
				break;
			}

			case SET_BLOCK_PROTECT:
			{
				e_25LCxx_interface_debug_print("STATE:%d SET BLOCK PROTECT\r\n", SET_BLOCK_PROTECT);
				if(e_25LCxx_basic_set_bp_status(E_25LCxx_BP01))                     /**< write protect the upper 25% of the memory */
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", SET_BLOCK_PROTECT);
					demo.state =  DEMO_IDLE;                                        /**< start over from idle if failed */
					return 1;														 /**< return error code */
				}
				u8PreviousState = demo.state;                                       /**< keep track of previous state */
				demo.state =  WRITE_BYTE;                                           /**< back to write state and attempt to write byte into the protected area*/
				break;
			}

			// Note: This function uses e_25LCxx_basic_update() to perform the write, so does not rewrites the value if it didn't change */
			case CHIP_ERASE:
			{
				e_25LCxx_interface_debug_print("STATE:%d CHIP ERASE\r\n", CHIP_ERASE);
				if(e_25LCxx_basic_chip_erase())                                     /**< execute chip erase */
				{
					e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", SET_BLOCK_PROTECT);
					demo.state =  DEMO_IDLE;                                        /**< start over from idle if failed */
					return 1;														 /**< return error code */
				}
				u8PreviousState = demo.state;                                       /**< keep track of previous state */
				demo.state = READ_FULL_MEMORY;                                      /**< go read full memory to confirm chip erase of the unprotected area */
				break;
			}

			case READ_FULL_MEMORY:
			{
				e_25LCxx_interface_debug_print("STATE:%d CHIP ERASE\r\n", CHIP_ERASE);
				for(u16EE_addr = 0; u16EE_addr < e_25LCxx_basic_get_eeprom_legth(); u16EE_addr++)
				{
					if(e_25LCxx_basic_read_byte(u16EE_addr, (uint8_t *)pBufferRead, 1)) /**< read 1 byte at the time and print */
					{
						e_25LCxx_interface_debug_print("failed to execute state :%d\r\n", READ_FULL_MEMORY);
						demo.state =  DEMO_IDLE;                                        /**< start over from idle if failed */
						break;
						return 1;														 /**< return error code */
						}else{
						e_25LCxx_interface_debug_print("address: %d \t data: %d\r\n",u16EE_addr, pBufferRead[0]);
					}
				}
				u8PreviousState = demo.state;                                           /**< keep track of previous state */
				demo.state =  DEMO_IDLE;                                                /**< start over from idle if failed */
				break;
			}

			default:
			e_25LCxx_interface_debug_print("demo code fatal error!!\r\n");
			return 1;
			break;

		}
    }

    return 1;
}

void led_toggling(void) {
    USER_LED_Toggle();
    led_time_check = Tick_Count();
}

void spi_chip_select(bool state) {
    if (state)
        SLAVE_SELECT_SetHigh();
    else
        SLAVE_SELECT_SetLow();
}

uint8_t spi_write(uint16_t u16Reg, uint32_t *pbuf, uint16_t u16Len) {
    int index;
    SPI1_Exchange8bit(u16Reg);
    if (u16Len == 0) {
        return 0;
    }
    for (index = 0; index < u16Len; index++) {
        SPI1_Exchange8bit(*pbuf);
        pbuf++;
    }

    return 0;
}

uint8_t spi_read(uint16_t u16Reg, uint32_t *pbuf, uint16_t u16Len) {
    SPI1_Exchange8bit(u16Reg);
    if (u16Len == 1) {
        *pbuf = SPI1_Exchange8bit(DUMMY_DATA);
        return 0;
    } else {
        while (u16Len > 0) {
            *pbuf = SPI1_Exchange8bit(DUMMY_DATA);
            pbuf++;
            u16Len--;
        }
    }

    return 0;
}