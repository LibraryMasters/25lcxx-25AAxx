#include <atmel_start.h>
#include <util/delay.h>
#include "25LCxx_driver_basic.h"

E_25LCxx_info_t e_25LCxxInfo;           /**< info structure object */

void delay_ms(uint32_t u32Ms);
uint8_t spi_read(uint8_t reg, uint8_t *pBuffer, size_t length);
uint8_t spi_write(uint8_t reg, uint8_t *pBuffer, size_t length);
uint8_t spi_chip_select(uint8_t status);

/** EEPROM 25LCxx application definition */ 
uint8_t pDataRead[20];					    /**< buffer to hold data read */
uint8_t pDataWrite[6] = {0x01, 2, 3, 0x4, 6, 0x05};			/**< buffer to hold data to write */
uint8_t numByteRead;						/**< number of bytes to read/write */
uint8_t singleByteDataRead;					/**< data to store single byte data read */
uint16_t dataAddress;						/**< eeprom address (read/write)*/

/**end of global definitions*/

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	e_25LCxx_basic_initialize(E_25LC160x_VARIANT, E_25LCXX_PAGE_SIZE_16_BYTE);
	E_25LCxx_info(&e_25LCxxInfo);
	
	#ifdef E_25LCXX_DEBUG_MODE
	e_25LCxx_interface_debug_print("Chip Name: \t%s\r\n", e_25LCxxInfo.chip_name);
	e_25LCxx_interface_debug_print("Manufacture: \t%s\r\n", e_25LCxxInfo.manufacturer_name);
	e_25LCxx_interface_debug_print("Interface: \t%s\r\n", e_25LCxxInfo.interface);
	e_25LCxx_interface_debug_print("Supply Volt Max: \t%.1fV\r\n", e_25LCxxInfo.supply_voltage_max_v);
	e_25LCxx_interface_debug_print("Supply Volt Min: \t%.1fV\r\n", e_25LCxxInfo.supply_voltage_min_v);
	e_25LCxx_interface_debug_print("Maximum Current: \t%.1fmA\r\n", e_25LCxxInfo.max_current_ma);
	e_25LCxx_interface_debug_print("Temperature Max: \t%.1fC\r\n", e_25LCxxInfo.temperature_max);
	e_25LCxx_interface_debug_print("Temperature Min: \t%.1fC\r\n", e_25LCxxInfo.temperature_min);
	e_25LCxx_interface_debug_print("Driver Version: \tV%.2f\r\n ", (e_25LCxxInfo.driver_version /1000));
	e_25LCxx_interface_debug_print("\n");
	#endif

	/* Replace with your application code */
	
	dataAddress = 0;          /**< start read operation at eeprom address 0*/
	numByteRead = 20;		  /**< read 10 bytes */
	e_25LCxx_basic_read_byte(dataAddress, (uint8_t *)pDataRead, numByteRead);
	for (int index = 0; index < numByteRead; index++){
		e_25LCxx_interface_debug_print("address read: %d Data Read :%x\n",index, pDataRead[index]);
	}

	dataAddress = 10;
	numByteRead = 10;
	memset(pDataRead, 0, 10);
	e_25LCxx_basic_update(dataAddress,(uint8_t *)pDataWrite, sizeof(pDataWrite));
	e_25LCxx_interface_delay_ms(10);
	e_25LCxx_basic_read_byte(dataAddress, (uint8_t *)pDataRead, numByteRead);
	for (int index = 0; index < numByteRead; index++){
		e_25LCxx_interface_debug_print("data: %d\n", pDataRead[index]);
	}


	//	e_25LCxx_basic_erase_sector(10, 20);
	for(int index = 0; index < e_25LCxx_basic_get_eeprom_legth(); index++){
		e_25LCxx_basic_read_byte(index, (uint8_t *)&singleByteDataRead, 1);
		e_25LCxx_interface_debug_print(" add: %d data: 0x%x", index, singleByteDataRead);
		if(index % 10 == 0)
		e_25LCxx_interface_debug_print("\n\r");
	}
	
	
	while (1) {
		LED_GREEN_toggle_level();
		e_25LCxx_interface_delay_ms(1000);
	}
}


void delay_ms(uint32_t u32Ms){
	
	while(u32Ms > 1){
		_delay_ms(1);
		u32Ms--;
	}

}

uint8_t spi_read(uint8_t reg, uint8_t *pBuffer, size_t length)
{
	SPI_0_write_block((uint8_t *)&reg, 1); 
	if(length == 1)
	{
		SPI_0_read_block((uint8_t *)pBuffer, 1);
	}
	SPI_0_read_block((uint8_t *)pBuffer, length);
	return 0;
}

uint8_t spi_write(uint8_t reg, uint8_t *pBuffer, size_t length)
{
	SPI_0_write_block((uint8_t *)&reg, 1);
	if(length == 0){return 0;}
	SPI_0_write_block((uint8_t *)pBuffer, length);	
	return 0;
}

uint8_t spi_chip_select(uint8_t status)
{
	SPI_NSS_set_level(status);
	return 0;
}